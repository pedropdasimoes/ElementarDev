var a = document.querySelectorAll("#aNavBar");
for(var i = 0; i < a.length; i++){
    a[i].addEventListener('click', () =>  {
        console.log('oioioi');
    });
}